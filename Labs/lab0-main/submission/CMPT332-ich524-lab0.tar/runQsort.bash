#Name: KAUR Shruti
#Student Number: 11339265
#NSID: ICH524

#!/bin/sh
datatype=$1
filename=$2
./bin/myQsort $datatype < $filename
