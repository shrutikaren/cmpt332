/*
 * Shruti Kaur
 * ich524
 * 11339265
 */

/* CMPT 332 GROUP Change, Fall 2024 */
/* Phase 1 */

#ifndef READER_WRITER_MONITOR_H
#define READER_WRITER_MONITOR_H

void Initialize(void);
void StartRead();
void StopRead();
void StartWrite();
void StopWrite();

#endif /* READER_WRITER_MONITOR_H */
